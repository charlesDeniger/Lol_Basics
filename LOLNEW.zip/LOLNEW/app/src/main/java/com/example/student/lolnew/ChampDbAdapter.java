package com.example.student.lolnew;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import android.database.SQLException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

/**
 * Created by Student on 4/23/2016.
 */
public class ChampDbAdapter {
    public static final String COL_ID = "_id";
    public static final String COL_NAME = "name";
    public static final String COL_GENDER = "gender";
    public static final String COL_MTYPE = "main_type";
    public static final String COL_STYPE = "secondary_type";
    public static final String COL_DIFFICULTY = "difficulty";
    public static final String COL_PASSIVE = "passive";
    public static final String COL_PASSIVE_D = "passive_description";
    public static final String COL_AB1 = "ability_1";
    public static final String COL_AB1_D = "ability_1_description";
    public static final String COL_AB2 = "ability_2";
    public static final String COL_AB2_D = "ability_2_description";
    public static final String COL_AB3 = "ability_3";
    public static final String COL_AB3_D = "ability_3_description";
    public static final String COL_AB4 = "ability_4";
    public static final String COL_AB4_D = "ability_4_description";

    public static final int INDEX_ID = 0;
    public static final int INDEX_NAME = INDEX_ID+1;
    public static final int INDEX_GENDER = INDEX_ID+2;
    public static final int INDEX_MTYPE = INDEX_ID+3;
    public static final int INDEX_STYPE = INDEX_ID+4;
    public static final int INDEX_DIFFICULTY = INDEX_ID+5;
    public static final int INDEX_PASSIVE = INDEX_ID+6;
    public static final int INDEX_PASSIVE_D = INDEX_ID+7;
    public static final int INDEX_AB1 = INDEX_ID+8;
    public static final int INDEX_AB1_D = INDEX_ID+9;
    public static final int INDEX_AB2 = INDEX_ID+10;
    public static final int INDEX_AB2_D = INDEX_ID+11;
    public static final int INDEX_AB3 = INDEX_ID+12;
    public static final int INDEX_AB3_D = INDEX_ID+13;
    public static final int INDEX_AB4 = INDEX_ID+14;
    public static final int INDEX_AB4_D = INDEX_ID+15;

    private SQLiteDatabase mDb;
    private DatabaseHelper mDbHelper;
    private static final String DATABASE_NAME = "dba_champ";
    private static final String TABLE_NAME = "tbl_champ";
    private static final int DATABASE_VERSION = 1;
    private final Context mCtx;

    private static final String DATABASE_CREATE =
            "CREATE TABLE if not exists " + TABLE_NAME + " (" +
                    COL_ID + " INTEGER PRIMARY KEY, " +
                    COL_NAME + " TEXT, " +
                    COL_GENDER + " TEXT, " +
                    COL_MTYPE + " TEXT, " +
                    COL_STYPE + " TEXT, " +
                    COL_DIFFICULTY + " INTEGER, " +
                    COL_PASSIVE + " TEXT, " +
                    COL_PASSIVE_D + " TEXT, " +
                    COL_AB1 + " TEXT, " +
                    COL_AB1_D + " TEXT, " +
                    COL_AB2 + " TEXT, " +
                    COL_AB2_D + " TEXT, " +
                    COL_AB3 + " TEXT, " +
                    COL_AB3_D + " TEXT, " +
                    COL_AB4 + " TEXT, " +
                    COL_AB4_D + " TEXT);";

    public ChampDbAdapter(Context ctx) {this.mCtx = ctx;}

    public void open() throws SQLException {
        Log.i("tag",DATABASE_CREATE);
        mDbHelper = new DatabaseHelper(mCtx);
        mDb = mDbHelper.getWritableDatabase();
    }
    public void close() {
        if(mDbHelper!= null){
            mDbHelper.close();
        }
    }
    public void createChampion(int id, String name, String gender, String mtype,
                               String stype, int diff, String passive, String dp, String ab1,
                               String dab1, String ab2, String dab2, String ab3, String dab3, String ab4, String dab4)
    {
        //Log.i("tag","WOW YOU GOT INTO THE CREATE CHAMP FUNCTION GOOD");
        ContentValues values = new ContentValues();
        values.put(COL_ID, id);
        values.put(COL_NAME, name);
        values.put(COL_GENDER, gender);
        values.put(COL_MTYPE, mtype);
        values.put(COL_STYPE, stype);
        values.put(COL_DIFFICULTY, diff);
        values.put(COL_PASSIVE, passive);
        values.put(COL_PASSIVE_D,dp);
        values.put(COL_AB1, ab1);
        values.put(COL_AB1_D,dab1);
        values.put(COL_AB2, ab2);
        values.put(COL_AB2_D,dab2);
        values.put(COL_AB3, ab3);
        values.put(COL_AB3_D, dab3);
        values.put(COL_AB4, ab4);
        values.put(COL_AB4_D,dab4);
        mDb.insert(TABLE_NAME, null, values);
    }
    private static class DatabaseHelper extends SQLiteOpenHelper {
        DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }
        @Override
        public void onCreate(SQLiteDatabase db) {
            //Log.w(TAG, DATABASE_CREATE);
            db.execSQL(DATABASE_CREATE);
        }
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            //Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
            //       + newVersion + ", which will destroy all old data");
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
            onCreate(db);
        }
    }
    public Cursor queryChamps(String gender, String mainT, int diff)
    {
        String q = "select * from tb1_champ ";
        String where = "";
        int num = 0;
        if(gender.equals("Male"))
            gender="m";
        if(gender.equals("Female"))
            gender="f";
        //String[] str = new String[]{"","",""};
        ArrayList<String> s = new ArrayList<String>();
        if(gender != "Any")
        {
            where+=COL_GENDER+"=?";
            s.add(gender);
            num++;
        }
        if(mainT != "Any")
        {
            if(num>0)
                where+=" AND ";
            where+=COL_MTYPE+"=?";
           // str[num]=mainT;
            s.add(mainT);
            num++;
        }
        if(diff!=-1)
        {
            if(num>0)
                where+=" AND ";
            where+=COL_DIFFICULTY+"=?";
            s.add(String.valueOf(diff));
            //str[num]=String.valueOf(diff);
        }
        Log.i("tag",""+s.size());
        String[] str = new String[s.size()];
        for(int i = 0; i < s.size(); i++)
            str[i] = s.get(i);
        Log.i("tag",where);
        //Log.i("tag",str[0]+" "+str[1]+" "+str[2]);
        //Log.i("tag",q);
        //Cursor cursor = mDb.rawQuery(q,new String[]{"m"});
        Log.i("tag","is it here?");

        Cursor cursor = mDb.query(TABLE_NAME, new String[]{COL_ID,COL_NAME,COL_GENDER,
                        COL_MTYPE,COL_STYPE,COL_DIFFICULTY,COL_PASSIVE,COL_PASSIVE_D, COL_AB1,COL_AB1_D,
                        COL_AB2,COL_AB2_D,COL_AB3,COL_AB3_D,COL_AB4,COL_AB4_D}, where,
                str,null,null,null,null);
        //Cursor cursor = mDb.rawQuery(q+where,str);
        if(cursor!=null)
            cursor.moveToFirst();
        else
            Log.i("tag","weird");
        return cursor;
    }
    public Champion fetchChamp(long id)
    {
        Cursor cursor = mDb.query(TABLE_NAME, new String[]{COL_ID,COL_NAME,COL_GENDER,
        COL_MTYPE,COL_STYPE,COL_DIFFICULTY,COL_PASSIVE,COL_PASSIVE_D, COL_AB1,COL_AB1_D,
        COL_AB2,COL_AB2_D,COL_AB3,COL_AB3_D,COL_AB4,COL_AB4_D}, COL_ID + "=?",
                new String[]{String.valueOf(id)},null,null,null,null);
        if(cursor!=null)
            cursor.moveToFirst();
        return new Champion(cursor.getInt(INDEX_ID),cursor.getString(INDEX_NAME), cursor.getString(INDEX_GENDER),
                cursor.getString(INDEX_MTYPE),cursor.getString(INDEX_STYPE),cursor.getInt(INDEX_DIFFICULTY),
                cursor.getString(INDEX_PASSIVE),cursor.getString(INDEX_PASSIVE_D),cursor.getString(INDEX_AB1),
                cursor.getString(INDEX_AB1_D),cursor.getString(INDEX_AB2),cursor.getString(INDEX_AB2_D),cursor.getString(INDEX_AB3),
                cursor.getString(INDEX_AB3_D),cursor.getString(INDEX_AB4),cursor.getString(INDEX_AB4_D));
    }
    public Cursor fetchAllChamps(){
        Cursor mCursor = mDb.query(TABLE_NAME, new String[]{COL_ID,COL_NAME,COL_GENDER,
                        COL_MTYPE,COL_STYPE,COL_DIFFICULTY,COL_PASSIVE,COL_PASSIVE_D,COL_AB1,COL_AB1_D,COL_AB2,
                        COL_AB2_D,COL_AB3,COL_AB3_D,COL_AB4,COL_AB4_D},
                null, null, null, null, null);

        if(mCursor!=null)
            mCursor.moveToFirst();
        return mCursor;
    }
    public void deleteAllChampions(){mDb.delete(TABLE_NAME, null, null);}

}




