package com.example.student.lolnew;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.widget.TextView;

/**
 * Created by Student on 5/4/2016.
 */
public class DetailActivity extends ActionBarActivity {
    private String name;
    private String gender;
    private String main;
    private String second;
    private int diff;
    private String pass;
    private String passD;
    private String q;
    private String qD;
    private String w;
    private String wD;
    private String e;
    private String eD;
    private String r;
    private String rD;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_activity);
        TextView nameT = (TextView) findViewById(R.id.nameTxt);
        TextView genderT = (TextView) findViewById(R.id.genderTxt);
        TextView mainT = (TextView) findViewById(R.id.mainTxt);
        TextView secondT = (TextView) findViewById(R.id.secondTxt);
        //TextView diffT = (TextView) findViewById(R.id.diffTxt);
        TextView passT = (TextView) findViewById(R.id.passTxt);
        TextView passDT = (TextView) findViewById(R.id.passDTxt);
        TextView qT = (TextView) findViewById(R.id.qTxt);
        TextView qDT = (TextView) findViewById(R.id.qDTxt);
        TextView wT = (TextView) findViewById(R.id.wTxt);
        TextView wDT = (TextView) findViewById(R.id.wDTxt);
        TextView eT = (TextView) findViewById(R.id.eTxt);
        TextView eDT = (TextView) findViewById(R.id.eDTxt);
        TextView rT = (TextView) findViewById(R.id.rTxt);
        TextView rDT = (TextView) findViewById(R.id.rDTxt);
        name = this.getIntent().getExtras().getString("nameID");
        gender = this.getIntent().getExtras().getString("genderID");
        main = this.getIntent().getExtras().getString("mainID");
        second = this.getIntent().getExtras().getString("secondID");
        pass = this.getIntent().getExtras().getString("passID");
        passD = this.getIntent().getExtras().getString("passDID");
        q = this.getIntent().getExtras().getString("qID");
        qD = this.getIntent().getExtras().getString("qDID");
        w = this.getIntent().getExtras().getString("wID");
        wD = this.getIntent().getExtras().getString("wDID");
        e = this.getIntent().getExtras().getString("eID");
        eD = this.getIntent().getExtras().getString("eDID");
        r = this.getIntent().getExtras().getString("rID");
        rD = this.getIntent().getExtras().getString("rDID");
        nameT.setText("Name: "+name);
        genderT.setText("Gender: "+gender);
        mainT.setText("Main Type: "+main);
        secondT.setText("Secondary Type: "+second);
        passT.setText("Passive: "+pass);
        passDT.setText(passD);
        qT.setText("Q Ability: "+q);
        qDT.setText(qD);
        wT.setText("W Ability: "+w);
        wDT.setText(wD);
        eT.setText("E Ability: "+e);
        eDT.setText(eD);
        rT.setText("R Ability: "+r);
        rDT.setText(rD);

    }
}
