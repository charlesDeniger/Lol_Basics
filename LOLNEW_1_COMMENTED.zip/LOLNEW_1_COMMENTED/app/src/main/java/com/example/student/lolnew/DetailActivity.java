package com.example.student.lolnew;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by Student on 5/4/2016.
 */
public class DetailActivity extends ActionBarActivity {

    private String id;
    private String name;
    private String gender;
    private String main;
    private String second;
    private String diff;
    private String pass;
    private String passD;
    private String q;
    private String qD;
    private String w;
    private String wD;
    private String e;
    private String eD;
    private String r;
    private String rD;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_activity);
        ImageView img = (ImageView) findViewById(R.id.img);
        TextView nameT = (TextView) findViewById(R.id.nameTxt);
        TextView genderT = (TextView) findViewById(R.id.genderTxt);
        TextView mainT = (TextView) findViewById(R.id.mainTxt);
        TextView secondT = (TextView) findViewById(R.id.secondTxt);
        TextView diffT = (TextView) findViewById(R.id.diffTxt);
        TextView passT = (TextView) findViewById(R.id.passTxt);
        TextView passDT = (TextView) findViewById(R.id.passDTxt);
        TextView qT = (TextView) findViewById(R.id.qTxt);
        TextView qDT = (TextView) findViewById(R.id.qDTxt);
        TextView wT = (TextView) findViewById(R.id.wTxt);
        TextView wDT = (TextView) findViewById(R.id.wDTxt);
        TextView eT = (TextView) findViewById(R.id.eTxt);
        TextView eDT = (TextView) findViewById(R.id.eDTxt);
        TextView rT = (TextView) findViewById(R.id.rTxt);
        TextView rDT = (TextView) findViewById(R.id.rDTxt);

        //extras from the main activity are assigned to variables in this activity
        id = this.getIntent().getExtras().getString("id");
        name = this.getIntent().getExtras().getString("nameID");
        gender = this.getIntent().getExtras().getString("genID");
        main = this.getIntent().getExtras().getString("mainID");
        second = this.getIntent().getExtras().getString("secondID");
        pass = this.getIntent().getExtras().getString("passID");
        passD = this.getIntent().getExtras().getString("passDID");
        diff = this.getIntent().getExtras().getString("diffID");
        q = this.getIntent().getExtras().getString("qID");
        qD = this.getIntent().getExtras().getString("qDID");
        w = this.getIntent().getExtras().getString("wID");
        wD = this.getIntent().getExtras().getString("wDID");
        e = this.getIntent().getExtras().getString("eID");
        eD = this.getIntent().getExtras().getString("eDID");
        r = this.getIntent().getExtras().getString("rID");
        rD = this.getIntent().getExtras().getString("rDID");

        String imgLink = "a"+id;//every image file is named as a(id number) as android studio would not allow me to
                                //use images that were just named according to their champions id number
        int resID = getResources().getIdentifier(imgLink,"mipmap",getPackageName());
        //this function retrieves an integer id that will then be used to display the image of the selected champion
        //imgLink is the file name we are searching fore, mipmap is the folders that we need to search through for
        //said file (our pics are in mipmap-xxhdpi specifically, and then getPackageName() simply returns the name of our package
        Log.i("tag", id+" "+resID);
        img.setImageResource(resID); //our previously found resID is used to set the source for our image box
        //after this point our variables derived from extras are assigned to the text fields below the image
        nameT.setText("Name: "+name+"\n");
        genderT.setText("Gender: "+gender+"\n");
        mainT.setText("Main Type: "+main+"\n");
        secondT.setText("Secondary Type: "+second+"\n");
        diffT.setText("Difficulty: "+diff+"\n");
        passT.setText("Passive: "+pass+"\n");
        passDT.setText(passD+"\n");
        qT.setText("Q Ability: "+q+"\n");
        qDT.setText(qD+"\n");
        wT.setText("W Ability: "+w+"\n");
        wDT.setText(wD+"\n");
        eT.setText("E Ability: "+e+"\n");
        eDT.setText(eD+"\n");
        rT.setText("R Ability: "+r+"\n");
        rDT.setText(rD);

    }
}
