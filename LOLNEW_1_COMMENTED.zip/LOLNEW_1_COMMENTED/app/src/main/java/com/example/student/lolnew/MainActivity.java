package com.example.student.lolnew;

import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.widget.SimpleCursorAdapter;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {

    private ChampDbAdapter dbChamp;
    private ListView champList;
    private Button qButton;
    private TextView test;
    private String[] diff;
    private String[] gen;
    private String[] main;
    private Spinner diffSpin;
    private Spinner genSpin;
    private Spinner mainSpin;
    private String[] from;
    private int[] to;
    private SimpleCursorAdapter ad;
    ProgressDialog mDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        test = (TextView)findViewById(R.id.textView);
        champList = (ListView) findViewById(R.id.champList);
        dbChamp = new ChampDbAdapter(this);
        diffSpin =(Spinner)findViewById(R.id.diffSpin);
        genSpin = (Spinner)findViewById(R.id.genderSpin);
        mainSpin = (Spinner)findViewById(R.id.mainSpin);
        qButton = (Button)findViewById(R.id.queryBtn);
        mDialog = new ProgressDialog(this);
        mDialog.setMessage("One Moment, Populating Database");
        mDialog.setCancelable(false);

        //diff is the array used to store the various difficulty levels that will be used to populate the difficulty spinner
        this.diff = new String[]{
                "Any","1","2","3","4","5","6","7","8","9","10"
        };

        //gen is the array used to store genders used to populate the gender spinner
        this.gen = new String[]{
            "Any","Male","Female"
        };

        //main is the array used to store main types used to populate the main type spinner
        this.main = new String[]{
          "Any","Tank","Fighter","Assassin","Mage","Support","Marksman"
        };

        //these adapters will all be used to populate their particular spinner
        ArrayAdapter<String> diffAd = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item,diff);
        ArrayAdapter<String> genAd = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item,gen);
        ArrayAdapter<String> mainAd = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item,main);
        diffSpin.setAdapter(diffAd);
        diffSpin.setPrompt("Difficulty");
        genSpin.setAdapter(genAd);
        genSpin.setPrompt("Gender");
        mainSpin.setAdapter(mainAd);
        mainSpin.setPrompt("Main Type");

        //we begin by opening the database
        dbChamp.open();

        //if the database does not already exist, delete all entries
        //and call the insertTest method
        if(savedInstanceState == null){
            dbChamp.deleteAllChampions();
            mDialog.show();
            insertTest();
            mDialog.dismiss();
        }

        //the whole database is queried into a cursor
        Cursor cursor = dbChamp.fetchAllChamps();
        int a = (cursor.getCount());

        //COL_NAME refers to the champion name stored at a specific index in the database
        from = new String[]{dbChamp.COL_NAME};

        //text_name is the textview used to display the champion name in the listview (found in row_champ.xml
        to = new int[]{R.id.text_name};

        //cursor filled with all champions
        ad = new ChampSimpleCursorAdapter(
                this,
                R.layout.row_champ,
                dbChamp.fetchAllChamps(),
                from,
                to,0);

        //set click listener for the query button
        qButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //store all current spinner values to string values
                String diff = ((String) diffSpin.getSelectedItem());
                String gender = (String) genSpin.getSelectedItem();
                String mainType = (String) mainSpin.getSelectedItem();
                int d;
                Cursor c;

                //if all the spinners are set to Any, fetch all champions
                if(diff.equals("Any") && gender.equals("Any") && mainType.equals("Any"))
                {
                    c = dbChamp.fetchAllChamps();
                }
                else {
                    if (diff.equals("Any"))
                        d = -1;
                    else
                        d = Integer.parseInt(diff);
                    Log.i("tag", "" + diff + " " + gender + " " + mainType);
                    c = dbChamp.queryChamps(gender, mainType, d);
                    Log.i("tag", "" + c.getCount());
                }
                String[] from = new String[]{dbChamp.COL_NAME};
                int[] to = new int[]{R.id.text_name};
                SimpleCursorAdapter a = new ChampSimpleCursorAdapter(MainActivity.this, R.layout.row_champ, dbChamp.fetchAllChamps(), from, to, 0);

                updateList(c);

            }
        });
        Log.i("tag", "" + ad + "");

        champList.setAdapter(ad);

        champList.setClickable(true);
        champList.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int position, long arg3){
                //nID is the selected position in the listview
                long nID = arg0.getItemIdAtPosition(position);

                //a champion is fetched based off the position in the listview
                Champion ch = dbChamp.fetchChamp(nID);

                //all important information about the champion is fetched and stored in string values
                String id = String.valueOf(ch.getmId());
                String nameID = ch.getmName();
                String genID = ch.getmGender();
                String mainID = ch.getmMainType();
                String secondID = ch.getmSecondaryType();
                String diffID = String.valueOf(ch.getmDifficulty());
                String passID = ch.getmPassive();
                String passDID = ch.getMPassiveD();
                String qID = ch.getmAB1();
                String qDID = ch.getmAB1D();
                String wID = ch.getmAB2();
                String wDID = ch.getmAB2D();
                String eID = ch.getmAB3();
                String eDID = ch.getmAB3D();
                String rID = ch.getmAB4();
                String rDID = ch.getmAB4D();
                Log.i("tag","wowowowowowowo"+diffID);

                //an intent is created for the detailactivity and all the champion info
                //is sent to it in extras
                Intent detailIntent = new Intent(MainActivity.this, DetailActivity.class);
                detailIntent.putExtra("id",id);
                detailIntent.putExtra("nameID",nameID);
                detailIntent.putExtra("genID",genID);
                detailIntent.putExtra("mainID",mainID);
                detailIntent.putExtra("secondID",secondID);
                detailIntent.putExtra("diffID",diffID);
                detailIntent.putExtra("passID",passID);
                detailIntent.putExtra("passDID",passDID);
                detailIntent.putExtra("qID",qID);
                detailIntent.putExtra("qDID",qDID);
                detailIntent.putExtra("wID",wID);
                detailIntent.putExtra("wDID",wDID);
                detailIntent.putExtra("eID",eID);
                detailIntent.putExtra("eDID",eDID);
                detailIntent.putExtra("rID",rID);
                detailIntent.putExtra("rDID",rDID);

                startActivity(detailIntent);
            }
        });

    }
    public void onClick(View v)
    {

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    //this function is used when an item from the ListView is selected
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //this function updates our ListView with new queries
    private void updateList(Cursor a)
    {
        ad.changeCursor(a);//the cursor adapter's cursor is switched to the passed cursor from the query
        ((BaseAdapter)champList.getAdapter()).notifyDataSetChanged();//the listview is told here that it's cursoradapter has been changed and will
                                                                    //then update according to the queried information in the new cursoradapter
    }

    //this function is used to read through our csv file
    private void insertTest()
    {
        try {
            //inputstream created based from csv file
            InputStream in = getResources().openRawResource(getResources().getIdentifier("lol", "raw", getPackageName()));

            //bufferreader created with inputstream
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String test = "";

            //while the bufferreader retrieves newlines
            //split the input with commas, store the information in strings
            //and create a champion with said strings
            while((test = br.readLine())!=null){
                String[] str = test.split(",");
                String  name, gender, main, second, pass_n, pass_d, qn, qd, wn, wd, en, ed, rn, rd;
                int id = Integer.parseInt(str[0]);
                name = str[1];
                gender = str[2];
                main = str[3];
                second = str[4];
                int difficult = Integer.parseInt(str[5]);
                pass_n = str[6];
                pass_d = str[7];
                qn = str[8];
                qd = str[9];
                wn = str[10];
                wd = str[11];
                en = str[12];
                ed = str[13];
                rn = str[14];
                rd = str[15];
                if(id == 0)
                    Log.i("tag",""+id+" "+name+ " "+gender+" "+main+" "+difficult+" "+pass_n+" "+pass_d+" "+qn+" "+qd+" "+wn+" "+wd+" "+wn+" "+en+" "+ed+" "+rn+" "+rd);
                dbChamp.createChampion(id,name,gender,main,second,difficult,pass_n,pass_d,qn,qd,wn,wd,en,ed,rn,rd);}

        }
        catch(IOException e)
        {
            Log.i("tag","PLEASE");
        }
        Log.i("tag", "adding to database");
    }
}
