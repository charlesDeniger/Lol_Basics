package com.example.student.lolnew;

import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.widget.SimpleCursorAdapter;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {

    private ChampDbAdapter dbChamp;
    private ListView champList;
    private Button qButton;
    private TextView test;
    private String[] diff;
    private String[] gen;
    private String[] main;
    private Spinner diffSpin;
    private Spinner genSpin;
    private Spinner mainSpin;
    private String[] from;
    private int[] to;
    private SimpleCursorAdapter ad;
    ProgressDialog mDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        test = (TextView)findViewById(R.id.textView);
        champList = (ListView) findViewById(R.id.champList);
        dbChamp = new ChampDbAdapter(this);
        diffSpin =(Spinner)findViewById(R.id.diffSpin);
        genSpin = (Spinner)findViewById(R.id.genderSpin);
        mainSpin = (Spinner)findViewById(R.id.mainSpin);
        qButton = (Button)findViewById(R.id.queryBtn);
        mDialog = new ProgressDialog(this);
        mDialog.setMessage("One Moment, Populating Database");
        mDialog.setCancelable(false);
        this.diff = new String[]{
                "Any","1","2","3","4","5","6","7","8","9","10"
        };
        this.gen = new String[]{
            "Any","Male","Female"
        };
        this.main = new String[]{
          "Any","Tank","Fighter","Assassin","Mage","Support","Marksman"
        };
        ArrayAdapter<String> diffAd = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item,diff);
        ArrayAdapter<String> genAd = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item,gen);
        ArrayAdapter<String> mainAd = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item,main);
        diffSpin.setAdapter(diffAd);
        diffSpin.setPrompt("Difficulty");
        genSpin.setAdapter(genAd);
        genSpin.setPrompt("Gender");
        mainSpin.setAdapter(mainAd);
        mainSpin.setPrompt("Main Type");
        dbChamp.open();
        if(savedInstanceState == null){
            dbChamp.deleteAllChampions();
            mDialog.show();
            insertTest();
            mDialog.dismiss();
        }
        Cursor cursor = dbChamp.fetchAllChamps();
        int a = (cursor.getCount());
        test.setText(""+a+"");
        //test.setText(cursor.getColumnIndexOrThrow(ChampDbAdapter.COL_PASSIVE_D));
        from = new String[]{dbChamp.COL_NAME};
        to = new int[]{R.id.text_name};
        ad = new ChampSimpleCursorAdapter(
                this,
                R.layout.row_champ,
                dbChamp.fetchAllChamps(),
                from,
                to,0);

        qButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String diff = ((String) diffSpin.getSelectedItem());
                String gender = (String) genSpin.getSelectedItem();
                String mainType = (String) mainSpin.getSelectedItem();
                int d;
                Cursor c;
                if(diff.equals("Any") && gender.equals("Any") && mainType.equals("Any"))
                {
                    c = dbChamp.fetchAllChamps();
                }
                else {
                    if (diff.equals("Any"))
                        d = -1;
                    else
                        d = Integer.parseInt(diff);
                    Log.i("tag", "" + diff + " " + gender + " " + mainType);
                    c = dbChamp.queryChamps(gender, mainType, d);
                    Log.i("tag", "" + c.getCount());
                }
                String[] from = new String[]{dbChamp.COL_NAME};
                int[] to = new int[]{R.id.text_name};
                SimpleCursorAdapter a = new ChampSimpleCursorAdapter(MainActivity.this, R.layout.row_champ, dbChamp.fetchAllChamps(), from, to, 0);

                updateList(c);

            }
        });
        Log.i("tag", "" + ad + "");

        champList.setAdapter(ad);

        champList.setClickable(true);
        champList.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int position, long arg3){
                //Object o = champList.getItemAtPosition(position);
                //String s = (String)o;
                long nID = arg0.getItemIdAtPosition(position);
                Champion ch = dbChamp.fetchChamp(nID);
                String nameID = ch.getmName();
                String genID = ch.getmGender();
                String mainID = ch.getmMainType();
                String secondID = ch.getmSecondaryType();
                int diffID = ch.getmId();
                String passID = ch.getmPassive();
                String passDID = ch.getMPassiveD();
                String qID = ch.getmAB1();
                String qDID = ch.getmAB1D();
                String wID = ch.getmAB2();
                String wDID = ch.getmAB2D();
                String eID = ch.getmAB3();
                String eDID = ch.getmAB3D();
                String rID = ch.getmAB4();
                String rDID = ch.getmAB4D();
                Intent detailIntent = new Intent(MainActivity.this, DetailActivity.class);
                detailIntent.putExtra("nameID",nameID);
                detailIntent.putExtra("genID",genID);
                detailIntent.putExtra("mainID",mainID);
                detailIntent.putExtra("secondID",secondID);
                detailIntent.putExtra("diffID",diffID);
                detailIntent.putExtra("passID",passID);
                detailIntent.putExtra("passDID",passDID);
                detailIntent.putExtra("qID",qID);
                detailIntent.putExtra("qDID",qDID);
                detailIntent.putExtra("wID",wID);
                detailIntent.putExtra("wDID",wDID);
                detailIntent.putExtra("eID",eID);
                detailIntent.putExtra("eDID",eDID);
                detailIntent.putExtra("rID",rID);
                detailIntent.putExtra("rDID",rDID);

                startActivity(detailIntent);
            }
        });

        //String[] from = new String[]{ChampDbAdapter.COL_NAME};
        //String str = "fail";
        //cursor.moveToFirst();
    }
    public void onClick(View v)
    {

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    private void updateList(Cursor a)
    {
        ad.changeCursor(a);
        ((BaseAdapter)champList.getAdapter()).notifyDataSetChanged();
    }
    private void insertTest()
    {
        try {
            InputStream in = getResources().openRawResource(getResources().getIdentifier("lol", "raw", getPackageName()));
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String test = "";
            while((test = br.readLine())!=null){
                String[] str = test.split(",");
                String  name, gender, main, second, pass_n, pass_d, qn, qd, wn, wd, en, ed, rn, rd;
                int id = Integer.parseInt(str[0]);
                name = str[1];
                gender = str[2];
                main = str[3];
                second = str[4];
                int difficult = Integer.parseInt(str[5]);
                pass_n = str[6];
                pass_d = str[7];
                qn = str[8];
                qd = str[9];
                wn = str[10];
                wd = str[11];
                en = str[12];
                ed = str[13];
                rn = str[14];
                rd = str[15];
                if(id == 0)
                    Log.i("tag",""+id+" "+name+ " "+gender+" "+main+" "+difficult+" "+pass_n+" "+pass_d+" "+qn+" "+qd+" "+wn+" "+wd+" "+wn+" "+en+" "+ed+" "+rn+" "+rd);
                dbChamp.createChampion(id,name,gender,main,second,difficult,pass_n,pass_d,qn,qd,wn,wd,en,ed,rn,rd);}

        }
        catch(IOException e)
        {
            Log.i("tag","PLEASE");
        }
        Log.i("tag", "adding to database");
        //dbChamp.createChampion(0, "test", "test", "test", "test", 0, "test", "test", "test", "test", "test", "test", "test", "test", "test", "test");
        //dbChamp.createChampion(1, "name_person", "test", "test", "test", 0, "test", "test", "test", "test", "test", "test", "test", "test", "test", "test");
    }
}
