package com.example.student.lolnew;


/**
 * Created by Student on 4/23/2016.
 */
public class Champion {
    private int mId;
    private String mName;
    private String mGender;
    private String mMainType;
    private String mSecondaryType;
    private int mDifficulty;
    private String mPassive;
    private String mPassiveD;
    private String mAB1;
    private String mAB1D;
    private String mAB2;
    private String mAB2D;
    private String mAB3;
    private String mAB3D;
    private String mAB4;
    private String mAB4D;

    public Champion(int id, String name, String gender, String main, String secondary,
                    int difficulty, String passive,String passiveD,String AB1,String AB1D,
                    String AB2,String AB2D, String AB3,String AB3D,
                    String AB4,String AB4D)
    {
        mId = id;
        mName = name;
        mGender = gender;
        mMainType = main;
        mSecondaryType = secondary;
        mDifficulty = difficulty;
        mPassive = passive;
        mPassiveD = passiveD;
        mAB1D = AB1D;
        mAB1 = AB1;
        mAB2 = AB2;
        mAB2D = AB2D;
        mAB3 = AB3;
        mAB3D = AB3D;
        mAB4 = AB4;
        mAB4D = AB4D;

    }
    public int getmId() {return mId;}
    public String getmName() {return mName;}
    public String getmGender() {return mGender;}
    public String getmMainType() {return mMainType;}
    public String getmSecondaryType() {return mSecondaryType;}
    public int getmDifficulty() {return mDifficulty;}
    public String getmPassive() {return mPassive;}
    public String getMPassiveD(){return mPassiveD;}
    public String getmAB1() {return mAB1;}
    public String getmAB1D(){return mAB1D;}
    public String getmAB2() {return mAB2;}
    public String getmAB2D(){return mAB2D;}
    public String getmAB3() {return mAB3;}
    public String getmAB3D(){return mAB3D;}
    public String getmAB4() {return mAB4;}
    public String getmAB4D(){return mAB4D;}
    public void setmId(int id) {mId = id;}
    public void setmName(String name) {mName = name;}
    public void setmGender(String gender) {mGender = gender;}
    public void setmMainType(String main) {mMainType = main;}
    public void setmSecondaryType(String second) {mSecondaryType = second;}
    public void setmDifficulty(int difficult) {mDifficulty = difficult;}
    public void setmPassive(String passive) {mPassive = passive;}
    public void setmPassiveD(String passiveD){mPassiveD = passiveD;}
    public void setmAB1(String ab1) {mAB1 = ab1;}
    public void setmAB1D(String ab1D){mAB1D = ab1D;}
    public void setmAB2(String ab2) {mAB2 = ab2;}
    public void setmAB2D(String ab2D){mAB2D = ab2D;}
    public void setmAB3(String ab3) {mAB3 = ab3;}
    public void setAB3D(String ab3D){mAB3D = ab3D;}
    public void setmAB4(String ab4) {mAB4 = ab4;}
    public void setmAB4D(String ab4D){mAB4D = ab4D;}


}


